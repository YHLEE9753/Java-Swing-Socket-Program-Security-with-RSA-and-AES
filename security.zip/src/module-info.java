module security {
	requires java.desktop;
}